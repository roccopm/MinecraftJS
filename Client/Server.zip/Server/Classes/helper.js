export function uuidv4() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
        (
            c ^
            (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
        ).toString(16)
    );
}

export function Vector2(x = 0, y = 0) {
    return { x, y };
}

export function RandomRange(min, max) {
    return Math.random() * (max - min) + min;
}
